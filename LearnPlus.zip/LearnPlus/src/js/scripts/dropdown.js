(function() {
  'use strict';

  // Disable Popper transforms - Conflicts with dropdown CSS transform effects
  // Popper.Defaults.modifiers.computeStyle.gpuAcceleration = false

})()

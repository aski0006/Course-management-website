(function() {
  'use strict';
      
  // Self Initialize DOM Factory Components
  domFactory.handler.autoInit()

  $('[data-toggle="tooltip"]').tooltip()

})()

import './main'
import './perfect-scrollbar'
import './preloader'
import './dropdown'
import './sidebar'

(function() {
  'use strict';

  ///////////////////////////////////
  // Custom JavaScript can go here //
  ///////////////////////////////////

})()
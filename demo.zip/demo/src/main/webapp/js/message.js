const MessageServiceType = {
    GET_ALL_MESSAGES: 1,
    GET_MESSAGES_BY_USER_ID: 2,
    SEARCH_MESSAGES: 3,
    ADD_MESSAGE: 4,
    UPDATE_MESSAGE: 5,
    DELETE_MESSAGE_BY_ID: 6
};
document.addEventListener("DOMContentLoaded", async function () {
    // 页面加载时立即显示消息列表
    await displayMessages();
});
window.Message = {
    displayMessages:displayMessages()
}
async function displayMessages() {
    try {
        // 获取所有消息
        const messages = await sendMessageRequest(MessageServiceType.GET_ALL_MESSAGES); // 直接使用返回的数组

        const messagesList = document.getElementById('messages-list');
        messagesList.innerHTML = ''; // 清空消息列表

        if (messages.length === 0) {
            // 显示提醒信息
            const noMessagesElement = document.createElement('div');
            noMessagesElement.className = 'no-messages';
            noMessagesElement.innerHTML = '<p>No messages available.</p>';
            messagesList.appendChild(noMessagesElement);
        } else {
            // 显示消息列表
            messages.forEach(message => {
                messagesList.appendChild(createMessageElement(message));
            });
        }
    } catch (e) {
        console.log("error" + e);
    }
}

const openMessageFormButton = document.getElementById('add-message-button');
const formContainer = document.getElementById('message-form-container');
const messageSendForm = document.getElementById('message-send-form');
openMessageFormButton.addEventListener('click',()=>{
    if (formContainer.style.display === 'none' || formContainer.style.display === '') {
        formContainer.style.display = 'block'; // 显示表单框
    } else {
        formContainer.style.display = 'none'; // 隐藏表单框
    }
})
messageSendForm.addEventListener('submit',async (event)=>{
    event.preventDefault();
    const content = document.getElementById('message-form-input').value;
    if(content){
        await sendMessageRequest(MessageServiceType.ADD_MESSAGE, {content});
        await displayMessages();
    }
})


function createMessageElement(message) {
    const messageElement = document.createElement('div');
    messageElement.className = 'message-item';

    let contentElement = document.createElement('h3');
    contentElement.textContent = message.Content;
    messageElement.appendChild(contentElement);

    contentElement = document.createElement('p');
    contentElement.textContent = message.Sender;
    messageElement.appendChild(contentElement);

    contentElement = document.createElement('p');
    contentElement.textContent = message.Role;
    messageElement.appendChild(contentElement);

    contentElement = document.createElement('p');
    contentElement.textContent = message.CreateTime;
    messageElement.appendChild(contentElement);


    if (localStorage.getItem('userId') === message.UserId.toString()) {
        const deleteButton = createButton('Delete', 'delete-button');
        deleteButton.addEventListener('click', async () => {
            try {
                await sendMessageRequest(MessageServiceType.DELETE_MESSAGE_BY_ID, {messageId: message.MessageId});
                await displayMessages();
            } catch (error) {
                alert('Failed to delete message: ' + error.message); // 更友好的用户反馈
                console.error('Failed to delete message:', error);
            }
        });
        messageElement.appendChild(deleteButton);

        const updateButton = createButton('Update', 'update-button');
        updateButton.addEventListener('click', async () => {
            const newContent = prompt('Enter new content:', message.Content);
            if (newContent) {
                try {
                    await sendMessageRequest(MessageServiceType.UPDATE_MESSAGE, {
                        newContent,
                        messageId: message.MessageId
                    });
                    await displayMessages();
                } catch (error) {
                    alert('Failed to update message: ' + error.message); // 更友好的用户反馈
                    console.error('Failed to update message:', error);
                }
            }
        });
        messageElement.appendChild(updateButton);
    }

    return messageElement;
}


function createButton(text, className) {
    const button = document.createElement('button');
    button.className = className;
    button.textContent = text;
    return button;
}

async function sendMessageRequest(type, data) {
    const url = 'MessageHandler'; // 替换为实际的后端API端点
    const requestBody = {
        type: type,
        ...data
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            console.error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}
document.addEventListener('DOMContentLoaded', function () {
    const userAvatar = document.getElementById('user-avatar');
    const userName = document.getElementById('user-name');
    const userRole = document.getElementById('user-role');
    const searchInput = document.getElementById('search-input');
    const editForm = document.getElementById('user-edit-form'); // 获取编辑表单元素
    const editNameInput = document.getElementById('edit-name'); // 获取编辑名字输入框
    const editButton = document.getElementById('edit-user-info');
    const saveEditButton = document.getElementById('save-user-info');

    // 设置头像背景色
    userAvatar.style.backgroundColor = getRandomColor();
    userAvatar.style.setProperty('--avatar-bg-color', userAvatar.style.backgroundColor);

    // Simulate fetching user data from LocalStorage
    const currentUser = JSON.parse(localStorage.getItem('currentUser')) || {
        name: localStorage.getItem('name') || 'Guest',
        role: localStorage.getItem('role') || 'Visitor'
    };

    // Fill in user info
    userName.textContent = currentUser.name;
    userRole.textContent = currentUser.role;

    // Fetch users when the page loads
    getUsers().then();

    // Search functionality
    searchInput.addEventListener('input', function () {
        const searchValue = searchInput.value.toLowerCase();
        const userItems = document.querySelectorAll('.user-item');
        userItems.forEach(item => {
            const name = item.querySelector('h4').textContent.toLowerCase();
            if (name.includes(searchValue)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });

    editButton.addEventListener('click', function () {
        if (editForm.style.display === 'block') {
            editForm.style.display = 'none'; // 如果编辑表单已经显示，则隐藏它
        } else {
            editForm.style.display = 'block'; // 如果编辑表单隐藏，则显示它
            editNameInput.value = userName.textContent; // 预填充当前用户名
        }
    });

    saveEditButton.addEventListener('click', () => {
        const newUserName = {
            newUserName: editNameInput.value
        };
        if (newUserName) {
            fetch('EditUserInfo', {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(newUserName)
                }
            ).then(response => {
                if (response.ok) {
                    return response.json();
                }
            }).then(async data => {
                userName.textContent = data.newName; // 更新用户名
                currentUser.name = data.newName; // 更新本地存储中的用户名
                localStorage.setItem('name', data.newName); // 保存到本地存储
                editForm.style.display = 'none'; // 隐藏编辑表单
                await getUsers();
            })
        }
    })
});
const userList = document.querySelector('.user-list');

// Fetch users from server
async function getUsers() {
    try {
        const response = await fetch('GetUsers', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        if (response.ok) {
            const users = await response.json();
            displayUsers(users);
        } else {
            console.log('Could not get users');
        }
    } catch (error) {
        console.error("Error fetching users:", error);
    }
}

// Display users
function displayUsers(users) {
    userList.innerHTML = ''; // Clear existing user list
    users.forEach(user => {
        const userItem = document.createElement('div');
        userItem.className = 'user-item';
        userItem.innerHTML = `
                <div class="avatar" style="background-color: #a2faac">
                    <i class="fas fa-user"></i> <!-- Font Awesome 用户图标 -->
                </div>
                <div>
                    <h4>${user.name}</h4>
                    <p>${user.role}</p>
                </div>
            `;
        userList.appendChild(userItem);
    });
}
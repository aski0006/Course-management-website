document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", function(event) {
        event.preventDefault(); // 阻止表单默认提交行为

        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
        const rememberMe = document.getElementById("rememberMe").checked;

        // 构建要发送的 JSON 数据
        const loginData = {
            username: username,
            password: password,
            rememberMe: rememberMe
        };

        // 发送 AJAX 请求
        fetch('Login', { // 替换为实际的登录API端点
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginData)
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    localStorage.setItem('role',data.role);
                    localStorage.setItem('name', data.name);
                    localStorage.setItem('userId', data.userId);
                    window.location.href = 'mainView.jsp';
                } else {
                    // 登录失败，显示错误信息
                    alert('Login failed: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Login failed: ' + error.message);
            });
    });
});
// 生成随机颜色
// 定义颜色数组
const colors = ['#E0FFFF', '#B0E0E6','#20B2AA','#FFFAFA','#FFFACD','#A4D3EE'];
function getRandomColor() {
    return colors[Math.floor(Math.random() * colors.length)];
}

// 生成稍浅的颜色
function getLighterColor(color) {
    const rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(color);
    let r = parseInt(rgb[1], 16);
    let g = parseInt(rgb[2], 16);
    let b = parseInt(rgb[3], 16);

    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}


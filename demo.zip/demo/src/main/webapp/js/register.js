document.addEventListener('DOMContentLoaded', function () {
    // 设置默认角色为学生
    document.getElementById('role').value = 'STUDENT';
});

const registerForm = document.getElementById('registerForm');
registerForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const name = document.getElementById('name').value;
    const role = document.getElementById('role').value;

    role.toUpperCase();

    const registerData = {
        username: username,
        password: password,
        name: name,
        role: role
    };

    fetch('Register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(registerData),
    }).then(response => {
        if (response.ok) {
            alert("Registration successful")
            window.location.href = "login.jsp";
        } else {
            throw new Error("error web");
        }
    }).catch(_ =>{
        throw new Error("error")
    })
});
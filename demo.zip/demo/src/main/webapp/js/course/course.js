document.addEventListener('DOMContentLoaded', function () {
    const formSteps = document.querySelectorAll('.form-step');
    const navPoints = document.querySelectorAll('.nav-point');
    const prevButton = document.getElementById('prev-step');
    const nextButton = document.getElementById('next-step');
    const closeFormButton = document.querySelector('.close-form');
    const openCreateFormButton = document.getElementById('open-course-form-button');
    let currentStep = 1;
    let role = localStorage.getItem('role');
    if (role == null) {
        role = 'TEACHER';
    } else {
        role = role.toUpperCase();
    }

    if (role === 'TEACHER') {
        openCreateFormButton.style.display = 'block';
    }
    openCreateFormButton.addEventListener('click', () => {
        let isView = document.querySelector('.create-course-form').style.display;
        if(isView === 'block'){
            document.querySelector('.create-course-form').style.display = 'none';
            document.querySelector('.course-details').style.display = 'none';
            document.querySelector('.course-list').style.display = 'block'
        }else{
            document.querySelector('.create-course-form').style.display = 'block';
            document.querySelector('.course-details').style.display = 'none';
            document.querySelector('.course-list').style.display = 'none'
        }
    })

    // 显示当前步骤
    function showStep(step) {
        formSteps.forEach((stepElement, index) => {
            if (index + 1 === step) {
                stepElement.classList.add('active');
            } else {
                stepElement.classList.remove('active');
            }
        });

        navPoints.forEach((point, index) => {
            if (index + 1 === step) {
                point.classList.add('active');
            } else {
                point.classList.remove('active');
            }
        });

        // 更新按钮状态
        prevButton.disabled = step === 1;

        if (step === formSteps.length) {
            nextButton.textContent = 'Create';
            nextButton.removeEventListener('click', nextStepHandler); // 移除旧的点击事件
            nextButton.addEventListener('click', submitForm); // 绑定提交表单事件
        } else {
            nextButton.textContent = 'Next';
            nextButton.removeEventListener('click', submitForm); // 移除提交表单事件
            nextButton.addEventListener('click', nextStepHandler); // 绑定下一步事件
        }
    }

    // 下一步按钮的点击事件
    function nextStepHandler() {
        if (currentStep < formSteps.length) {
            currentStep++;
            showStep(currentStep);
        }
    }


    // 提交表单的点击事件
    function submitForm(event) {
        event.preventDefault(); // 阻止默认提交行为

        // 获取表单元素
        const courseForm = document.getElementById('course-form');

        // 检查表单是否有效
        if (courseForm.checkValidity()) {
            // 获取表单数据
            const formData = new FormData(courseForm);

            // 将表单数据转换为 JSON 对象
            const courseData = {
                courseName: formData.get('courseName'),
                description: formData.get('description'),
                credits: parseInt(formData.get('credits')),
                semester: formData.get('semester'),
                year: parseInt(formData.get('year')),
                prerequisites: formData.get('prerequisites'),
                capacity: parseInt(formData.get('capacity')),
                classTime: formData.get('classTime'),
                location: formData.get('location')
            };

            // 发送 fetch 请求
            fetch('AddCourse', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(courseData)
            })
                .then(response => {
                    if (response.ok) {
                        return response.json(); // 解析 JSON 响应
                    } else {
                        throw new Error('Failed to create course.');
                    }
                })
                .then(data => {
                    // 处理成功响应
                    alert('Course created successfully!');
                    const event = new Event('courseSubmitted');
                    courseForm.reset(); // 重置表单
                    showStep(1); // 回到第一步
                })
                .catch(error => {
                    // 处理错误响应
                    alert('Error: ' + error.message);
                });
        } else {
            // 提示用户填写必填项
            alert('Please fill out all required fields.');
        }
    }

    // 导航点点击事件
    navPoints.forEach(point => {
        point.addEventListener('click', function () {
            const step = parseInt(this.getAttribute('data-step'));
            showStep(step);
            currentStep = step;
        });
    });

    // 上一步按钮
    prevButton.addEventListener('click', function () {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
        }
    });

    // 关闭表单按钮
    closeFormButton.addEventListener('click', function () {
        document.querySelector('.create-course-form').style.display = 'none';
    });

    // 初始化显示第一步
    showStep(currentStep);
});
const editCourseDetailsButton = document.getElementById('edit-course-info');
editCourseDetailsButton.addEventListener('click',()=>{
    document.getElementById('course-form').style.display = 'block';
})
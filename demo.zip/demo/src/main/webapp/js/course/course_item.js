document.addEventListener('DOMContentLoaded', function () {

    document.addEventListener('courseSubmitted', function () {
        fetchCourses().then(); // 监听自定义事件并调用 fetchCourses
    });
    // 向后端发送 POST 请求获取课程数据
    // 初始化时获取课程列表
    fetchCourses().then();
    // 默认隐藏 course-details
    courseDetails.style.display = 'none';
});
const courseList = document.querySelector('.course-list');
const courseDetails = document.querySelector('.course-details');
const openCreateFormButton = document.getElementById('open-course-form-button');
// 添加返回按钮

document.getElementById('back-to-list').addEventListener('click', () => {
    courseDetails.style.display = 'none'; // 隐藏 course-details
    courseList.style.display = 'block'; // 显示 course-list
    openCreateFormButton.style.display = 'block';
});

async function fetchCourses() {
    try {
        const response = await fetch('GetCourseList', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            console.log("Error fetching courses")
        }

        const courses = await response.json(); // 解析 JSON 数据
        renderCourses(courses); // 渲染课程列表
    } catch (error) {
        console.error('Error fetching courses:', error);
    }
}

// 动态生成 course-item 并添加到 course-list
function renderCourses(courses) {
    courseList.innerHTML = ''; // 清空现有内容
    courses.forEach(course => {
        const courseItem = document.createElement('div');
        courseItem.classList.add('course-item');
        courseItem.innerHTML = `
                <h3>${course.courseName}</h3>
                <p><strong>ID:</strong> ${course.courseId}</p>
                <p><strong>Description:</strong> ${course.description}</p>
                <p><strong>Credits:</strong> ${course.credits}</p>
                <p><strong>Capacity:</strong> ${course.capacity}</p>
                <p><strong>Semester:</strong> ${course.semester} ${course.year}</p>
                <p><strong>Class Time:</strong> ${course.classTime}</p>
                <p><strong>Location:</strong> ${course.location}</p>
            `;
        courseItem.addEventListener('click', () => showCourseDetails(course));
        courseList.appendChild(courseItem);
    });
}

const course1 = {
    courseName: "高数",
    credits: 5,
    year: 2024,
    description: "这是高数",
    semester: "第一学期",
    location: "第一教学楼508教室",
    courseId: 1,
    classTime: "18",
    capacity: 50
};
const course2 = {
    prerequisites: "None",
    courseName: "Introduction to Java",
    credits: 3,
    year: 2024,
    description: "Learn the basics of Java programming.",
    semester: "Fall",
    location: "Room 101, Main Building",
    courseId: 2,
    classTime: "Mon, Wed 10:00 AM - 11:30 AM",
    capacity: 60
};

// 显示课程详情
// 显示课程详情
function showCourseDetails(course) {
    courseList.style.display = 'none'; // 隐藏 course-list
    courseDetails.style.display = 'block'; // 显示 course-details
    openCreateFormButton.style.display = 'none';

    // 获取左侧和右侧的容器
    const leftContainer = document.querySelector('.course-details-left-container');
    const rightContainer = document.querySelector('.course-details-right-container');

    // 清空左侧和右侧的内容
    leftContainer.innerHTML = '';
    rightContainer.innerHTML = '';

    // 添加左侧简略信息
    const summaryContent = document.createElement('div');
    summaryContent.innerHTML = `
        <h2>${course.courseName}</h2>
        <p><strong>ID:</strong> ${course.courseId}</p>
        <p><strong>Description:</strong> ${course.description.slice(0, 10)}...</p>
        <p><strong>Credits:</strong> ${course.credits}</p>
        <p><strong>Capacity:</strong> ${course.capacity}</p>
        <p><strong>Semester:</strong> ${course.semester} ${course.year}</p>
        <p><strong>Class Time:</strong> ${course.classTime}</p>
        <p><strong>Location:</strong> ${course.location}</p>
    `;
    leftContainer.appendChild(summaryContent);

    // 添加右侧四个板块
    const sectionsContainer = document.createElement('div');
    sectionsContainer.classList.add('course-sections');
    const sections = ['section', 'homework', 'test', 'discussion'];
    sections.forEach(section => {
        const sectionTab = document.createElement('div');
        sectionTab.classList.add('section-tab');
        sectionTab.textContent = section;
        sectionTab.addEventListener('click', () => {
            // 移除所有板块的 active 类
            document.querySelectorAll('.section-tab').forEach(tab => tab.classList.remove('active'));
            // 添加当前板块的 active 类
            sectionTab.classList.add('active');

            // window.location.href = section + '.jsp';
            window.location.href = section + '.html';
        });
        sectionsContainer.appendChild(sectionTab);
    });
    rightContainer.appendChild(sectionsContainer);


}
function changeContent(content) {
    const contents = document.querySelectorAll('#main .card');
    for (let i = 0; i < contents.length; i++) {
        contents[i].style.display = 'none';
    }
    document.getElementById(content).style.display = 'block';
}

changeContent('course'); // Default content

// main.js
document.addEventListener("DOMContentLoaded", function () {
    // 获取按钮元素
    const updateButton = document.getElementById("update-info-button");

    // 添加点击事件监听器
    updateButton.addEventListener("click", async function () {
        try {
            // 调用 getUsers 方法
            await getUsers();

            // 调用 fetchCourses 方法
            await fetchCourses();

            // 调用 displayMessages 方法
            await displayMessages();

            console.log("All data updated successfully!");
        } catch (error) {
            console.error("Error updating data:", error);
        }
    });
});

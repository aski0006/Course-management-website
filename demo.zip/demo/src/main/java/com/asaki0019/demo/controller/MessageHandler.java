package com.asaki0019.demo.controller;

import com.asaki0019.demo.dao.MessageDao;
import com.asaki0019.demo.dao.UserDao;
import com.asaki0019.demo.dao.implement.MessageDaoImpl;
import com.asaki0019.demo.dao.implement.UserDaoImpl;
import com.asaki0019.demo.service.MessageService;
import com.asaki0019.demo.service.implement.MessageServiceImpl;
import com.asaki0019.demo.utils.BaseServlet;
import com.asaki0019.demo.utils.JsonUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "MessageHandlerServlet", value = "/MessageHandler")

public class MessageHandler extends BaseServlet {
    private static MessageService messageService;

    public void init() throws ServletException {
        super.init();
        MessageDao mDao = new MessageDaoImpl();
        UserDao uDao = new UserDaoImpl();
        messageService = new MessageServiceImpl(uDao, mDao);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        // TODO:
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JsonUtils.setContentTypeUT8AndJson(request, response);
        var json = JsonUtils.getJsonFromRequest(request);
        if (json == null) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write(JsonUtils.createFailureJson("json 错误").toString());
            return;
        }
        var result = messageService.handleRequest(json, request,response);
        response.getWriter().write(result.toString());
    }

    public void destroy() {
    }
}
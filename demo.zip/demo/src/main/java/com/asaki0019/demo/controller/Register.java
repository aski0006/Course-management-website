package com.asaki0019.demo.controller;

import java.io.*;

import com.asaki0019.demo.dao.implement.UserDaoImpl;
import com.asaki0019.demo.service.UserService;
import com.asaki0019.demo.service.implement.UserServiceImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "RegisterServlet", value = "/Register")

public class Register extends HttpServlet {
    private static UserService userService;

    public void init() throws ServletException {
        super.init();
        var userDao = new UserDaoImpl();
        userService = new UserServiceImpl(userDao);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // TODO:
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        userService.register(request, response);
    }

    public void destroy() {
    }
}
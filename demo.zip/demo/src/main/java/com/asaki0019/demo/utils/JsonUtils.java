package com.asaki0019.demo.utils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.logging.Logger;

public class JsonUtils {
    private static final Logger LOG = Logger.getLogger(JsonUtils.class.getName());

    public static JSONObject getJsonFromRequest(HttpServletRequest request) {
        StringBuilder jsonStringBuilder = new StringBuilder();
        String line;
        try (BufferedReader reader = request.getReader()) {
            while ((line = reader.readLine()) != null) {
                jsonStringBuilder.append(line);
            }
        } catch (IOException e) {
            LOG.info(e.getMessage());
            return null;
        }
        return new JSONObject(jsonStringBuilder.toString());
    }

    public static void setContentTypeUT8AndJson(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
    }

    public static String toJsonString(JSONObject jsonObject) {
        return jsonObject.toString();
    }

    /**
     * 创建一个表示操作结果的JSON对象
     *
     * @param success 操作是否成功
     * @param message 操作结果的消息
     * @return JSONObject表示的操作结果
     */
    public static JSONObject createResponseJson(boolean success, String message) {
        JSONObject responseJson = new JSONObject();
        responseJson.put("success", success);
        responseJson.put("message", message);
        return responseJson;
    }

    /**
     * 创建一个表示操作成功的JSON对象
     *
     * @param message 成功消息
     * @return JSONObject表示的成功结果
     */
    public static JSONObject createSuccessJson(String message) {
        return createResponseJson(true, message);
    }

    /**
     * 创建一个表示操作失败的JSON对象
     *
     * @param message 失败消息
     * @return JSONObject表示的失败结果
     */
    public static JSONObject createFailureJson(String message) {
        return createResponseJson(false, message);
    }

}
package com.asaki0019.demo.dao.implement;

import com.asaki0019.demo.dao.MessageDao;
import com.asaki0019.demo.model.Message;
import com.asaki0019.demo.utils.DBUtils;

import java.util.List;
import java.util.Map;

public class MessageDaoImpl implements MessageDao {

    @Override
    public List<Map<String, Object>> selectMessagesArray() {
        return DBUtils.executeQuery("SELECT * FROM messages");
    }

    @Override
    public List<Map<String, Object>> selectMessagesByUserId(Integer userId) {
        return DBUtils.executeQuery("SELECT * FROM messages WHERE UserId = ?", userId);

    }

    @Override
    public List<Map<String, Object>> selectMessagesByContentLike(String content) {
        String sql = "SELECT * FROM messages WHERE Content LIKE concat('%', ?, '%')";
        return DBUtils.executeQuery(sql, content);
    }

    @Override
    public boolean insertMessageByUserId(Message newMessage) {
        String sql = "INSERT INTO messages (UserId, Content, CreateTime, UpdateTime) VALUES (?, ?, NOW(), NOW())";
        return DBUtils.executeUpdate(sql, newMessage.getUserId(), newMessage.getContent());
    }

    @Override
    public boolean updateMessagesByUserId(Message newMessage, Integer messageId) {
        String sql = "UPDATE messages SET Content = ?, UpdateTime = NOW() WHERE MessageId = ?";
        return DBUtils.executeUpdate(sql, newMessage.getContent(), messageId);
    }

    @Override
    public boolean deleteMessagesByMessageId(Integer messageId) {
        String sql = "DELETE FROM messages WHERE MessageId = ?";
        return DBUtils.executeUpdate(sql, messageId);
    }
}
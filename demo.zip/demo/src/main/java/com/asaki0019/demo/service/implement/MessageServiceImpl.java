package com.asaki0019.demo.service.implement;

import com.asaki0019.demo.dao.MessageDao;
import com.asaki0019.demo.dao.UserDao;
import com.asaki0019.demo.model.Message;
import com.asaki0019.demo.model.User;
import com.asaki0019.demo.service.MessageService;
import com.asaki0019.demo.type.MessageServiceType;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MessageServiceImpl implements MessageService {

    private final MessageDao messageDao;
    private final UserDao userDao;

    public MessageServiceImpl(UserDao userDao, MessageDao messageDao) {
        this.userDao = userDao;
        this.messageDao = messageDao;
    }

    @Override
    public JSONArray getAllMessages() {
        JSONArray messagesArray = convertToJSONArray(messageDao.selectMessagesArray());
        if (messagesArray.isEmpty()) {
            return new JSONArray();
        }
        Map<Integer, User> userMap = userDao.selectAllUsers().stream()
                .collect(Collectors.toMap(User::getUserID, user -> user));
        for (int i = 0; i < messagesArray.length(); i++) {
            JSONObject message = messagesArray.getJSONObject(i);
            Integer userId = message.getInt("UserId");
            User user = userMap.get(userId);
            if (user != null) {
                message.put("Sender", user.getName());
                message.put("Role", user.getRole().toString());
            }
        }
        return messagesArray;
    }

    @Override
    public JSONArray getMessagesByUserId(Integer userId) {
        return convertToJSONArray(messageDao.selectMessagesByUserId(userId));
    }

    @Override
    public JSONArray searchMessages(String content) {
        return convertToJSONArray(messageDao.selectMessagesByContentLike(content));
    }

    @Override
    public boolean addMessage(Message message) {
        return messageDao.insertMessageByUserId(message);
    }

    @Override
    public boolean updateMessage(Message message, Integer messageId) {
        return messageDao.updateMessagesByUserId(message, messageId);
    }

    @Override
    public boolean deleteMessageById(Integer messageId) {
        return messageDao.deleteMessagesByMessageId(messageId);
    }

    @Override
    public JSONArray handleRequest(JSONObject json,
                                   HttpServletRequest request,
                                   HttpServletResponse response) {
        var type = json.getInt("type");
        if (type == -1) {
            return new JSONArray().put(new JSONObject().put("error", "Invalid type"));
        }
        try {
            var user = (User) request.getSession(false).getAttribute("user");
            var userId = user.getUserID();
            MessageServiceType serviceType = MessageServiceType.fromType(type);
            switch (serviceType) {
                case GET_ALL_MESSAGES -> {
                    return getAllMessages();
                }
                case GET_MESSAGES_BY_USER_ID -> {
                    return getMessagesByUserId(userId);
                }
                case SEARCH_MESSAGES -> {
                    var content = json.getString("content");
                    return searchMessages(content);
                }
                case ADD_MESSAGE -> {
                    var content = json.getString("content");
                    var newMessage = new Message(userId, content);
                    boolean added = addMessage(newMessage);
                    return new JSONArray().put(new JSONObject().put("status", added ? "success" : "error"));
                }
                case UPDATE_MESSAGE -> {
                    var content = json.getString("newContent");
                    var messageId = json.getInt("messageId");
                    var newMessage = new Message(userId, content);
                    boolean updated = updateMessage(newMessage, messageId);
                    return new JSONArray().put(new JSONObject().put("status", updated ? "success" : "error"));
                }
                case DELETE_MESSAGE_BY_ID -> {
                    var messageId = json.getInt("messageId");
                    boolean deleted = deleteMessageById(messageId);
                    return new JSONArray().put(new JSONObject().put("status", deleted ? "success" : "error"));
                }
                default -> {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    return new JSONArray().put(new JSONObject().put("error", "Unsupported operation"));
                }
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return new JSONArray().put(new JSONObject().put("error", "Internal server error  :" + MessageServiceType.fromType(type)));
        }
    }

    private JSONArray convertToJSONArray(List<Map<String, Object>> messagesList) {
        JSONArray jsonArray = new JSONArray();
        if (messagesList != null && !messagesList.isEmpty()) {
            for (Map<String, Object> messageMap : messagesList) {
                jsonArray.put(new JSONObject(messageMap));
            }
        }
        return jsonArray;
    }
}
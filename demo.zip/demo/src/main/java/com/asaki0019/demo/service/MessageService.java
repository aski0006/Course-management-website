package com.asaki0019.demo.service;


import com.asaki0019.demo.model.Message;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

public interface MessageService {

    /**
     * 获取所有留言信息
     *
     * @return JSONArray 包含所有留言的JSON数组，如果无留言则包含{"status": "no messages"}
     */
    JSONArray getAllMessages();

    /**
     * 根据用户ID获取留言信息
     *
     * @param userId 用户ID
     * @return JSONArray 包含该用户所有留言的JSON数组，如果无留言则包含{"status": "no messages"}
     */
    JSONArray getMessagesByUserId(Integer userId);

    /**
     * 根据Content模糊搜错消息
     *
     * @param content 消息内容
     * @return JSONArray 包含该用户所有留言的JSON数组，如果无留言则包含{"status": "no messages"}
     */
    JSONArray searchMessages(String content);
    /**
     * 添加一条新留言
     *
     * @param message 留言对象
     * @return boolean 添加成功返回true，否则返回false
     */
    boolean addMessage(Message message);

    /**
     * 更新一条留言信息
     *
     * @param message 留言对象
     * @return boolean 更新成功返回true，否则返回false
     */
    boolean updateMessage(Message message, Integer messageId);

    /**
     * 根据留言ID删除一条留言
     *
     * @param messageId 留言ID
     * @return boolean 删除成功返回true，否则返回false
     */
    boolean deleteMessageById(Integer messageId);


    JSONArray handleRequest(JSONObject json,
                            HttpServletRequest request,
                            HttpServletResponse response);
}
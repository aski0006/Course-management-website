package com.asaki0019.demo.model;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private int messageId;
    private int userId;
    private String content;
    private Date createTime;
    private Date updateTime;

    // Constructors
    public Message() {
    }

    public Message(int userId, String content) {
        this.userId = userId;
        this.content = content;
    }

    // Getters and Setters
    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    // toString method
    @Override
    public String toString() {
        return "Message{" +
                "messageId=" + messageId +
                ", userId=" + userId +
                ", content='" + content + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
package com.asaki0019.demo.dao.implement;

import com.asaki0019.demo.dao.CourseDao;
import com.asaki0019.demo.model.Course;
import com.asaki0019.demo.utils.DBUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CourseDaoImpl implements CourseDao {

    @Override
    public List<Map<String, Object>> getAllCourse() {
        String sql = "SELECT * FROM my_web.courseinfo";
        return DBUtils.executeQuery(sql);
    }

    @Override
    public List<Map<String, Object>> getCourseByCourseId(Integer CourseId) {
        String sql = "SELECT * FROM my_web.courseinfo WHERE CourseID = ?";
        return DBUtils.executeQuery(sql, CourseId);
    }

    @Override
    public List<Map<String, Object>> getCourseByTeacherId(Integer teacherId) {
        return getCoursesByRelationId("my_web.courseteachers",teacherId);
    }

    @Override
    public List<Map<String, Object>> getCourseByStudentId(Integer studentId) {
        return getCoursesByRelationId("my_web.coursestudents",studentId);
    }

    /**
     * 根据关系表中的 ID 获取课程信息
     *
     * @param relationColumn 关系表中的列名（如 "TeacherID" 或 "StudentID"）
     * @param relationId     关系表中的 ID 值
     * @return 课程信息列表
     */
    private List<Map<String, Object>> getCoursesByRelationId(String tableName,Integer relationId) {
        // 1. 查询关系表，获取课程 ID 列表
        var sql = "SELECT CourseID FROM "+tableName+" WHERE UserId = ?";
        var courseIdList = DBUtils.executeQuery(sql, relationId);

        // 如果 courseIdList 为空，说明没有关联的课程，直接返回空列表
        if (courseIdList == null || courseIdList.isEmpty()) {
            return new ArrayList<>();
        }

        // 2. 提取课程 ID 列表
        var courseIds = courseIdList.stream()
                .map(map -> map.get("CourseID"))
                .map(Object::toString)
                .collect(Collectors.joining(","));

        // 3. 查询 courseinfo 表，获取对应课程的详细信息
        var courseSql = "SELECT * FROM my_web.courseinfo WHERE CourseID IN (" + courseIds + ")";

        // 4. 返回课程详细信息
        return DBUtils.executeQuery(courseSql);
    }

    @Override
    public void addCourseByTeacherId(Integer teacherId, Course course) {
        Connection conn = null;
        PreparedStatement courseStmt = null;
        PreparedStatement teacherCourseStmt = null;
        ResultSet generatedKeys = null;

        try {
            // 获取数据库连接
            conn = DBUtils.getConnection();

            // 开启事务
            conn.setAutoCommit(false);

            // 1. 插入课程信息到 courseinfo 表
            String insertCourseSQL = "INSERT INTO courseinfo (CourseName, Description, Credits, Semester, Year, Prerequisites, Capacity, ClassTime, Location) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            courseStmt = conn.prepareStatement(insertCourseSQL, Statement.RETURN_GENERATED_KEYS);
            DBUtils.setParams(courseStmt,
                    course.getCourseName(),
                    course.getDescription(),
                    course.getCredits(),
                    course.getSemester(),
                    course.getYear(),
                    course.getPrerequisites(),
                    course.getCapacity(),
                    course.getClassTime(),
                    course.getLocation());

            // 执行插入操作
            int affectedRows = courseStmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating course failed, no rows affected.");
            }

            // 获取生成的 CourseId
            generatedKeys = courseStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int courseId = generatedKeys.getInt(1); // 获取自动生成的 CourseId
                course.setCourseId(courseId); // 将生成的 CourseId 设置到 Course 对象中
            } else {
                throw new SQLException("Creating course failed, no ID obtained.");
            }

            // 2. 插入关联信息到 courseteachers 表
            String insertTeacherCourseSQL = "INSERT INTO courseteachers (CourseID, UserID) VALUES (?, ?)";
            teacherCourseStmt = conn.prepareStatement(insertTeacherCourseSQL);
            DBUtils.setParams(teacherCourseStmt, course.getCourseId(), teacherId);

            // 执行插入操作
            teacherCourseStmt.executeUpdate();

            // 提交事务
            conn.commit();

        } catch (SQLException e) {
            // 回滚事务
            try {
                conn.rollback();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            System.out.println(e.getMessage());
        } finally {
            // 恢复自动提交
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
            }

            // 关闭资源
            DBUtils.close(conn, courseStmt, generatedKeys);
            DBUtils.close(null, teacherCourseStmt, null);
        }
    }
}
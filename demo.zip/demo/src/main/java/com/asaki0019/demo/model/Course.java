package com.asaki0019.demo.model;

import javax.persistence.*;


@Entity
@Table(name = "courseinfo")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer courseId;

    private String courseName;

    private String description;

    private Integer credits;

    private String semester;

    private Integer year;

    private String prerequisites;

    private Integer capacity;

    private String classTime;

    private String location;

    // Getters and Setters

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCredits() {
        return credits;
    }

    public void setCredits(Integer credits) {
        this.credits = credits;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(String prerequisites) {
        this.prerequisites = prerequisites;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public String getClassTime() {
        return classTime;
    }

    public void setClassTime(String classTime) {
        this.classTime = classTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    // Constructors

    public Course() {
    }

    public Course(Integer courseId, String courseName, String description, Integer credits, String semester, Integer year, String prerequisites, Integer capacity, String classTime, String location) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.description = description;
        this.credits = credits;
        this.semester = semester;
        this.year = year;
        this.prerequisites = prerequisites;
        this.capacity = capacity;
        this.classTime = classTime;
        this.location = location;
    }

    // toString method

    @Override
    public String toString() {
        return "Course{" +
                "courseId=" + courseId +
                ", courseName='" + courseName + '\'' +
                ", description='" + description + '\'' +
                ", credits=" + credits +
                ", semester='" + semester + '\'' +
                ", year=" + year +
                ", prerequisites='" + prerequisites + '\'' +
                ", capacity=" + capacity +
                ", classTime='" + classTime + '\'' +
                ", location='" + location + '\'' +
                '}';
    }


}
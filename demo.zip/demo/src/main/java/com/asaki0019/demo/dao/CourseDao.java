package com.asaki0019.demo.dao;

import com.asaki0019.demo.model.Course;

import java.util.List;
import java.util.Map;

public interface CourseDao {
    List<Map<String, Object>> getAllCourse();

    List<Map<String, Object>> getCourseByCourseId(Integer CourseId);
    List<Map<String, Object>> getCourseByTeacherId(Integer TeacherId);
    List<Map<String, Object>> getCourseByStudentId(Integer StudentId);
    void addCourseByTeacherId(Integer teacherId, Course course);

}

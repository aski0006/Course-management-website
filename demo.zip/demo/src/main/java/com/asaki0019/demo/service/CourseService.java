package com.asaki0019.demo.service;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;

public interface CourseService {
    JSONArray getCourseList(HttpServletRequest request, HttpServletResponse response);

    void addCourse(HttpServletRequest request, HttpServletResponse response);
}

package com.asaki0019.demo.controller.course;

import java.io.*;

import com.asaki0019.demo.dao.implement.CourseDaoImpl;
import com.asaki0019.demo.service.CourseService;
import com.asaki0019.demo.service.implement.CourseServiceImpl;
import com.asaki0019.demo.utils.BaseServlet;
import com.asaki0019.demo.utils.JsonUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "AddCourseServlet", value = "/AddCourse")

public class AddCourse extends BaseServlet {

    private static CourseService courseService;
    public void init() throws ServletException {
        super.init();
        var courseDao = new CourseDaoImpl();
        courseService = new CourseServiceImpl(courseDao);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // TODO:
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JsonUtils.setContentTypeUT8AndJson(request,response);
        courseService.addCourse(request,response);
    }

    public void destroy() {
    }
}
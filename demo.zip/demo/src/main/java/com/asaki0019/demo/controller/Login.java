package com.asaki0019.demo.controller;

import java.io.*;

import com.asaki0019.demo.dao.implement.UserDaoImpl;
import com.asaki0019.demo.service.UserService;
import com.asaki0019.demo.service.implement.UserServiceImpl;
import com.asaki0019.demo.utils.JsonUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
@WebServlet(name = "LoginServlet", value = "/Login")

public class Login extends HttpServlet {
    private static UserService userService;

    public void init() throws ServletException {
        super.init();
        var userDao = new UserDaoImpl();
        userService = new UserServiceImpl(userDao);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // TODO:
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JsonUtils.setContentTypeUT8AndJson(request,response);
        var res = userService.login(request, response);
        response.getWriter().write(res.toString());
    }
    public void destroy() {
    }
}
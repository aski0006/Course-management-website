package com.asaki0019.demo.dao.implement;

import com.asaki0019.demo.dao.UserDao;
import com.asaki0019.demo.model.Course;
import com.asaki0019.demo.model.User;
import com.asaki0019.demo.utils.DBUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class UserDaoImpl implements UserDao {

    @Override
    public User selectUserById(Integer userId) {
        String sql = "SELECT * FROM my_web.users WHERE UserID = ?";
        return queryUser(sql, userId);
    }

    @Override
    public User selectUserByUsername(String username) {
        String sql = "SELECT * FROM my_web.users WHERE Username = ?";
        return queryUser(sql, username);
    }

    @Override
    public boolean insertUser(User user) {
        String sql = "INSERT INTO my_web.users (Username, Password, Role, Name) VALUES (?, ?, ?, ?)";
        return DBUtils.executeUpdate(sql, user.getUsername(), user.getPassword(), user.getRole().toString(), user.getName());
    }

    @Override
    public boolean updateUser(User user) {
        String sql = "UPDATE my_web.users SET Password = ?, Role = ?, Name = ? WHERE UserID = ?";
        return DBUtils.executeUpdate(sql, user.getPassword(), user.getRole().toString(), user.getName(), user.getUserID());
    }

    @Override
    public boolean deleteUserById(Integer userId) {
        String sql = "DELETE FROM my_web.users WHERE UserID = ?";
        return DBUtils.executeUpdate(sql, userId);
    }

    @Override
    public List<User> selectAllUsers() {
        String sql = "SELECT * FROM my_web.users";
        List<Map<String, Object>> list = DBUtils.executeQuery(sql);
        if (list == null) return new ArrayList<>();
        return list.stream().map(this::convertMapToUser).collect(Collectors.toList());
    }

    @Override
    public boolean checkUsernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM my_web.users WHERE Username = ?";
        List<Map<String, Object>> list = DBUtils.executeQuery(sql, username);
        Map<String, Object> map = new HashMap<>();
        if (list != null && !list.isEmpty()) {
            map = list.getFirst();
        }
        return (Integer) map.get("COUNT(*)") != 0;
    }

    @Override
    public boolean bindStudentToCourse(User user, Course course) {
        return false;
    }

    @Override
    public boolean bindTeacherToCourse(User user, Course course) {
        return false;
    }

    private User queryUser(String sql, Object... params) {
        List<Map<String, Object>> list = DBUtils.executeQuery(sql, params);
        if (list != null && !list.isEmpty()) {
            Map<String, Object> map = list.getFirst();
            return convertMapToUser(map);
        }
        return null;
    }

    private User convertMapToUser(Map<String, Object> map) {
        User user = new User();
        user.setUserID((Integer) map.get("UserID"));
        user.setUsername((String) map.get("Username"));
        user.setPassword((String) map.get("Password"));
        String roleValue = ((String) map.get("Role")).toUpperCase();
        user.setRole(User.Role.valueOf(roleValue));
        user.setName((String) map.get("Name"));
        return user;
    }
}
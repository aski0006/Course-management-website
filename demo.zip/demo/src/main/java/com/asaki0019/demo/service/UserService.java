package com.asaki0019.demo.service;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

public interface UserService {
    JSONObject login(HttpServletRequest request, HttpServletResponse response);

    void register(HttpServletRequest request, HttpServletResponse response);

    void logout(HttpServletRequest request, HttpServletResponse response);

    JSONArray getAllUsers(HttpServletRequest request, HttpServletResponse response);

    JSONObject editUserInfo(HttpServletRequest request, HttpServletResponse response);
}

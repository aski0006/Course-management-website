package com.asaki0019.demo.utils;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class DBUtils {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/my_web";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";
    private static final Logger LOG = Logger.getLogger(DBUtils.class.getName());

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            LOG.severe("这是一个严重错误: " + e.getMessage());
        }
    }

    // 获取数据库连接
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
        } catch (SQLException e) {
            LOG.severe("Exception " + e.getMessage());
            throw new RuntimeException("Failed to get database connection.");
        }
    }

    public static void close(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            LOG.severe("Exception " + e.getMessage());
            throw new RuntimeException("Failed to close database connection.");
        }
    }


    public static boolean executeUpdate(String sql, Object... params) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(sql);
            setParams(ps, params);
            int i = ps.executeUpdate();
            if (i > 0) return true;
        } catch (SQLException e) {
            LOG.severe("Exception " + e.getMessage());
        } finally {
            close(conn, ps, null);
        }
        return false;
    }

    public static List<Map<String, Object>> executeQuery(String sql, Object... params) { //可变参数  Object... params
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet set = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(sql);
            setParams(ps, params);
            set = ps.executeQuery();
            List<Map<String, Object>> list = new ArrayList<>();
            int count = set.getMetaData().getColumnCount();
            while (set.next()) {
                Map<String, Object> map = new HashMap<>();
                for (int i = 0; i < count; i++) {
                    String name = set.getMetaData().getColumnLabel(i + 1);
                    map.put(name, set.getObject(name));
                }
                list.add(map);
            }
            return list;
        } catch (Exception e) {
            LOG.severe("Exception " + e.getMessage());
        } finally {
            close(conn, ps, set);
        }
        return null;
    }

    public static void setParams(PreparedStatement stmt, Object... params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            stmt.setObject(i + 1, params[i]);
        }
    }
}


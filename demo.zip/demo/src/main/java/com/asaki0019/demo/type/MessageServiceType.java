package com.asaki0019.demo.type;

public enum MessageServiceType {
    GET_ALL_MESSAGES(1, "getAllMessages"),
    GET_MESSAGES_BY_USER_ID(2, "getMessagesByUserId"),
    SEARCH_MESSAGES(3, "searchMessages"),
    ADD_MESSAGE(4, "addMessage"),
    UPDATE_MESSAGE(5, "updateMessage"),
    DELETE_MESSAGE_BY_ID(6, "deleteMessageById");

    private final int type;
    private final String methodName;

    MessageServiceType(int type, String methodName) {
        this.type = type;
        this.methodName = methodName;
    }

    public int getType() {
        return type;
    }

    public String getMethodName() {
        return methodName;
    }

    public static MessageServiceType fromType(int type) {
        for (MessageServiceType serviceType : values()) {
            if (serviceType.getType() == type) {
                return serviceType;
            }
        }
        throw new IllegalArgumentException("Invalid type: " + type);
    }
}
package com.asaki0019.demo.dao;

import com.asaki0019.demo.model.Message;

import java.util.List;
import java.util.Map;

public interface MessageDao {
    List<Map<String, Object>> selectMessagesArray();

    List<Map<String, Object>> selectMessagesByUserId(Integer userId);

    List<Map<String, Object>> selectMessagesByContentLike(String content);

    boolean insertMessageByUserId(Message newMessage);

    boolean updateMessagesByUserId(Message newMessage, Integer messageId);

    boolean deleteMessagesByMessageId(Integer messageId);
}

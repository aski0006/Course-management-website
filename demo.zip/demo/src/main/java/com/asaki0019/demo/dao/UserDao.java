package com.asaki0019.demo.dao;

import com.asaki0019.demo.model.Course;
import com.asaki0019.demo.model.User;

import java.util.List;

public interface UserDao {
    User selectUserById(Integer userId);
    User selectUserByUsername(String username);
    boolean insertUser(User user);
    boolean updateUser(User user);
    boolean deleteUserById(Integer userId);
    List<User> selectAllUsers();
    boolean checkUsernameExists(String username);

    boolean bindStudentToCourse(User user, Course course);
    boolean bindTeacherToCourse(User user, Course course);
}


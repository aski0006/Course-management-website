package com.asaki0019.demo.service.implement;

import com.asaki0019.demo.dao.CourseDao;
import com.asaki0019.demo.model.Course;
import com.asaki0019.demo.model.User;
import com.asaki0019.demo.service.CourseService;
import com.asaki0019.demo.utils.JsonUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class CourseServiceImpl implements CourseService {
    private static CourseDao courseDao;
    private static final Logger LOG = Logger.getLogger(CourseServiceImpl.class.getName());
    public CourseServiceImpl(CourseDao courseDao){
       CourseServiceImpl.courseDao = courseDao;
    }


    @Override
    public JSONArray getCourseList(HttpServletRequest request, HttpServletResponse response) {
        var jsonArray = new JSONArray();
        var user = (User) request.getSession(false).getAttribute("user");
        if(user == null){
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return jsonArray;
        }
        List<Course> courseList;
        if(user.getRole().equals(User.Role.STUDENT)){
            courseList = convertToCourseList(courseDao.getCourseByStudentId(user.getUserID()));
        }
        else{
            courseList = convertToCourseList(courseDao.getCourseByTeacherId(user.getUserID()));
        }
        for(var course:courseList){
            var json = convertCourseToJsonObject(course);
            jsonArray.put(json);
        }
        response.setStatus(HttpServletResponse.SC_OK);
        return jsonArray;
    }

    @Override
    public void addCourse(HttpServletRequest request, HttpServletResponse response) {
        var jsonObject = JsonUtils.getJsonFromRequest(request);
        if(jsonObject == null){
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return;
        }
        try {
            Course course = new Course();
            course.setCourseName(jsonObject.getString("courseName"));
            course.setDescription(jsonObject.getString("description"));
            course.setCredits(jsonObject.getInt("credits"));
            course.setSemester(jsonObject.getString("semester"));
            course.setYear(jsonObject.getInt("year"));
            course.setPrerequisites(jsonObject.getString("prerequisites"));
            course.setCapacity(jsonObject.getInt("capacity"));
            course.setClassTime(jsonObject.getString("classTime"));
            course.setLocation(jsonObject.getString("location"));

            var user = (User)request.getSession(false).getAttribute("user");
            if(user == null || user.getRole().equals(User.Role.STUDENT)){
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("Teacher ID not found in session.");
                return;
            }
            var teacherId = user.getUserID();

            courseDao.addCourseByTeacherId(teacherId,course);
            // 返回成功响应
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("Course added successfully.");

        } catch (org.json.JSONException e) {
            LOG.severe("Error parsing JSON: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            try {
                response.getWriter().write("Invalid JSON format.");
            } catch (IOException ex) {
                LOG.severe("Error writing response: " + ex.getMessage());
            }
        } catch (Exception e) {
            LOG.severe("Error adding course: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try {
                response.getWriter().write("Failed to add course.");
            } catch (IOException ex) {
                LOG.severe("Error writing response: " + ex.getMessage());
            }
        }
    }

    public List<Course> convertToCourseList(List<Map<String, Object>> courseMapList) {
        return courseMapList.stream()
                .map(this::convertMapToCourse)
                .collect(Collectors.toList());
    }

    private Course convertMapToCourse(Map<String, Object> courseMap) {
        Course course = new Course();
        course.setCourseId((Integer) courseMap.get("CourseID"));
        course.setCourseName((String) courseMap.get("CourseName"));
        course.setDescription((String) courseMap.get("Description"));
        course.setCredits((Integer) courseMap.get("Credits"));
        course.setSemester((String) courseMap.get("Semester"));
        course.setYear((Integer) courseMap.get("Year"));
        course.setPrerequisites((String) courseMap.get("Prerequisites"));
        course.setCapacity((Integer) courseMap.get("Capacity"));
        course.setClassTime((String) courseMap.get("ClassTime"));
        course.setLocation((String) courseMap.get("Location"));
        return course;
    }

   private JSONObject convertCourseToJsonObject(Course course) {
        if (course == null) {
            return null; // 如果传入的 Course 对象为 null，则返回 null
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("courseId", course.getCourseId());
        jsonObject.put("courseName", course.getCourseName());
        jsonObject.put("description", course.getDescription());
        jsonObject.put("credits", course.getCredits());
        jsonObject.put("semester", course.getSemester());
        jsonObject.put("year", course.getYear());
        jsonObject.put("prerequisites", course.getPrerequisites());
        jsonObject.put("capacity", course.getCapacity());
        jsonObject.put("classTime", course.getClassTime());
        jsonObject.put("location", course.getLocation());

        return jsonObject;
    }
}
package com.asaki0019.demo.service.implement;

import com.asaki0019.demo.dao.UserDao;
import com.asaki0019.demo.model.User;
import com.asaki0019.demo.service.UserService;
import com.asaki0019.demo.utils.JsonUtils;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Base64;

public class UserServiceImpl implements UserService {
    private static UserDao userDao;

    public UserServiceImpl(UserDao userDao) {
        UserServiceImpl.userDao = userDao;
    }

    @Override
    public JSONObject login(HttpServletRequest request, HttpServletResponse response) {
        var json = JsonUtils.getJsonFromRequest(request);
        if (json == null) {
            response.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
            return new JSONObject();
        }

        var username = json.getString("username");
        var password = json.getString("password");

        var verifiedUser = userDao.selectUserByUsername(username);
        if (verifiedUser == null) {
            response.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
            return new JSONObject();
        }

        var responseJson = new JSONObject();
        if (password.equals(verifiedUser.getPassword())) {
            var session = request.getSession(true);
            session.setAttribute("user", verifiedUser);
            if (json.optBoolean("rememberMe", false)) {
                String cookieValue = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());
                Cookie cookie = new Cookie("auth", cookieValue);
                cookie.setMaxAge(60 * 60); // 设置Cookie有效期为一小时
                cookie.setPath("/"); // 设置Cookie路径
                response.addCookie(cookie);
            }
            responseJson.put("success", true);
            responseJson.put("name", verifiedUser.getName());
            responseJson.put("role", verifiedUser.getRole());
            responseJson.put("userId", verifiedUser.getUserID());
        } else {
            responseJson.put("success", false);
        }
        response.setStatus(HttpServletResponse.SC_OK);
        return responseJson;
    }

    @Override
    public void register(HttpServletRequest request, HttpServletResponse response) {
        var json = JsonUtils.getJsonFromRequest(request);
        if (json == null) {
            response.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
            return;
        }
        var user = new User();
        user.setUsername(json.getString("username"));
        user.setPassword(json.getString("password"));
        user.setName(json.getString("name"));
        user.setRole(User.Role.valueOf(json.getString("role").toUpperCase()));
        var Ok = userDao.insertUser(user);
        response.setStatus(
                Ok ? HttpServletResponse.SC_OK : HttpServletResponse.SC_BAD_GATEWAY
        );
    }

    @Override
    public void logout(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public JSONArray getAllUsers(HttpServletRequest request, HttpServletResponse response) {
        var userList = userDao.selectAllUsers();
        var jsonArray = new JSONArray();
        for (var user : userList) {
            var json = new JSONObject();
            json.put("name", user.getName());
            json.put("role", user.getRole());
            jsonArray.put(json);
        }
        response.setStatus(HttpServletResponse.SC_OK);
        return jsonArray;
    }

    @Override
    public JSONObject editUserInfo(HttpServletRequest request, HttpServletResponse response) {
        var json = JsonUtils.getJsonFromRequest(request);
        var res = new JSONObject();
        if (json == null) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return res;
        }
        var newUserName = json.getString("newUserName");
        var oldUser = (User) request.getSession(false).getAttribute("user");
        var newUser = new User();
        newUser.setRole(oldUser.getRole());
        newUser.setName(newUserName);
        newUser.setUserID(oldUser.getUserID());
        newUser.setPassword(oldUser.getPassword());
        if (userDao.updateUser(newUser)) {
            response.setStatus(HttpServletResponse.SC_OK);
        } else {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
        res.put("newName", newUser.getName());
        return res;
    }

}